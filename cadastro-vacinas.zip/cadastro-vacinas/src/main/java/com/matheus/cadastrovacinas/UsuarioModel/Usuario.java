package com.matheus.cadastrovacinas.UsuarioModel;

import javax.persistence.Column;
import javax.persistence.Entity;


@Entity(name = "Usuario")
public class Usuario {


    @Column(nullable = false, length = 45)
    private String nome;

    @Column(nullable = false, length = 14, unique = true)
    private String cpf;

    @Column(nullable = false, length = 14, unique = true)
    private String email;

    @Column(nullable = false, length = 10)
    private String dataNasc;

    public void setNome(String nome){
        this.nome = nome;
    }

    public void setCpf(String cpf){
        this.cpf = cpf;
    }

    public void setEmail(String email){
        this.email = email;
    }
    
    public void setData(String data){
        this.dataNasc = data;
    }
}
