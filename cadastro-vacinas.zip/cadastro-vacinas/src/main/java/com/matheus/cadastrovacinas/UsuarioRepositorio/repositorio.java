package com.matheus.cadastrovacinas.UsuarioRepositorio;

import com.matheus.cadastrovacinas.UsuarioModel.Usuario;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface repositorio extends JpaRepository <Usuario, Long> {
    
}
