package com.matheus.cadastrovacinas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CadastroDeVacinasApplicationTests {

	@Test
	void contextLoads() {
	}

}
